<footer class="footer">
    <div class="container-fluid">
       <div class="row">
          <div class="col-sm-6">
            <script>document.write(new Date().getFullYear())</script> © Bangladesh Diabetic Association.
          </div>
          <div class="col-sm-6">
            <div class="text-sm-right d-none d-sm-block">
               Developed by <a href="https://cthealth-bd.com/" target="_blank">CT Health Ltd.</a>
            </div>
          </div>
       </div>
    </div>
 </footer>