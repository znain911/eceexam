<div class="row">
    <div class="col-xl-12">
       <div class="card">
        <div class="card-body">
            <div class="row">
                
            </div>
        </div>
       </div>
    </div> <!-- end col -->
        
</div>

                        