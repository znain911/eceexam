<?php
Class A_settings_m extends CI_Model{

	public function get_registration_control($id)
	{
		$this -> db -> select('*');
		$this -> db -> from(DB_PREFIX.'settings');
		$this -> db -> where('id', $id);
		$query = $this->db->get();
		return $query->first_row();
	}

   
    public function registration_control_update($id,$data) {
        //Transfering data to Model
		$this->db->trans_start();
		$this->db->where('id', $id);
		$this->db->update(DB_PREFIX.'settings', $data);		
		$this->db->trans_complete();					
   	} // End of function
	
	


}//end of Class 
?>